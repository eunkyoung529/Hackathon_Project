from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms

class SignUpForm(UserCreationForm):
    first_name = forms.CharField(max_length=30, required=True)  # 이름 필드 추가

    class Meta:
        model = User
        fields = ("username", "password", "first_name")

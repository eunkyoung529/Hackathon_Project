const map = L.map('map').setView([0, 0], 2); 

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

// 거리 계산 함수
function calculateDistance(lat1, lon1, lat2, lon2) {
    return map.distance([lat1, lon1], [lat2, lon2]);
}


// 포획된 위치를 추적
let capturedLocations = [];

// 포인트 및 캡쮸리 데이터 POST
function postCaptureData(location, points, images) {
    fetch('/api/collect-capture', { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ captureName: location, points: points, capture: images})
    })
    .then(response => response.json())
    .then(data => {
        alert(`${location}의 캡쮸리를 포획하였습니다! ${points} 포인트를 획득하였습니다.`);
        capturedLocations.push(location);  // 포획한 위치 저장
    })
    .catch(error => {
        console.error("캡쮸리 데이터 전송 중 오류 발생:", error);
    });
}

// 위치 목록
const locations = [
    { name: "test", lat: 37.649331, lon: 127.0217685, image: "sc/붕어빵.png", capname: "붕어빵",points: 100},
    { name: "덕성여대", lat: 37.6512976, lon: 127.01654434204102, image: "sc/덕성여대.png", capname: "덕성여대",points: 100 },
    { name: "덕성여대 차미리사관", lat: 37.65297122936526, lon: 127.01637268066406, image: "sc/디소공.png", capname: "디소공",points: 100 },
    { name: "해남군", lat: 34.5735165884839, lon: 126.599270065365, image: "sc/해남군.jpg", capname: "해남 이크누스",points: 100 },
    { name: "해남군", lat: 34.4928221, lon: 126.494087, image: "sc/해남 고구마.jpg", capname: "해남 고구마",points: 100 },
    { name: "옹진군", lat: 37.9534650042648, lon: 124.670086072277, image: "sc/옹진군.jpg", capname: "옹진 영흥 하늘 고래",points: 100 },
    { name: "청양군", lat: 36.4592146952303, lon: 126.80220021685, image: "sc/청양군.jpg", capname: "고추빵", points: 100 },
    { name: "양구군", lat: 38.1100012808234, lon: 127.989950629015, image: "sc/양구군.jpg", capname: "돼지", points: 100 },
    { name: "양양군", lat: 38.073838757652, lon: 128.62280130386353, image: "sc/양양 서핑.png", capname: "양양 서핑",points: 100 },
    { name: "과천시", lat: 37.4292328036839, lon: 126.987720998734, image: "sc/과천 사과.png", capname: "과천 사과",points: 100 },
];

if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
        function(position) {
            const userLat = position.coords.latitude;
            const userLon = position.coords.longitude;

            map.setView([userLat, userLon], 15);

            // 사용자 위치
            L.marker([userLat, userLon]).addTo(map)
                .bindPopup("<b>현재 위치</b>")
                .openPopup();

            // 위치 목록 처리
            locations.forEach(loc => {
                // 포획된 위치가 아닌 경우만 마커 표시
                if (!capturedLocations.includes(loc.name)) {
                    const distance = calculateDistance(userLat, userLon, loc.lat, loc.lon);
                    if (distance <= 50) {
                        alert(`${loc.capname}의 캡쮸리를 포획하였습니다! ${loc.points} 포인트를 획득하였습니다.`);
                        postCaptureData(loc.name, loc.points, loc.image);  // 포획 데이터 전송
                    } else {
                        // 위치에 마커 추가
                        L.marker([loc.lat, loc.lon]).addTo(map)
                            .bindPopup(`
                                <div style="text-align: center;">
                                    <img src="${loc.image}" width="100" height="100" alt="${loc.name} 캡쮸리" style="display: block; margin: 0 auto;">
                                    <h3>${loc.name}</h3>
                                    <p>${loc.capname} 캡쮸리를 획득할 수 있어요!</p>
                                </div>
                            `);
                    }
                }
            });
        },
        function() {
            alert("위치를 가져올 수 없습니다.");
        }
    );
} else {
    alert("Geolocation이 이 브라우저에서 지원되지 않습니다.");
}

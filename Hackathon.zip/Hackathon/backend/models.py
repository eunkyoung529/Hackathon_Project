from django.db import models

# Create your models here.
from django.contrib.auth.models import User

class Item(models.Model):
    item_name = models.CharField(max_length=100)  # 아이템 이름
    item_image = models.FileField()
    points_spent = models.IntegerField()  # 사용 포인트

    def __str__(self):
        return self.name
    
class UserPurchased(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Django 기본 User와 연결
    item = models.ForeignKey(Item, on_delete=models.CASCADE)

    def __str__(self):
        return self.name

class UserInfo(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Django 기본 User와 연결
    points = models.IntegerField()
    
    def __str__(self):
        return self.name
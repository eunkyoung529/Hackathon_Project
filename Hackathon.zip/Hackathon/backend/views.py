# views.py
import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt  # CSRF 비활성화가 필요할 경우

# views.py
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from .forms import SignUpForm
from .forms import LoginForm
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required

#1117에 추가함.
# from django.http import HttpResponseNotFound
from django.http import HttpResponse

def home_logout_view(request):
    return render(request, 'home_logout.html')  # 템플릿 파일 위치는 templates/home.html

def join_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        name = request.POST.get('first_name')
        
        if not username or not password or not name:
            return HttpResponse("All fields are required.", status=400)
        try:
            User.objects.create_user(username=username, password=password, first_name=name)
            return redirect('home_login')
        except Exception as e:
            return HttpResponse(f"Error: {str(e)}", status=400)
    return render(request, "join_logout.html")

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        # 사용자 인증
        user = authenticate(request, username=username, password=password)  #로그인 검증ㄱ

        if user is not None:
            # 인증 성공 시 로그인
            login(request, user)
            # return redirect('home_login')  # 로그인 후 이동할 페이지 (예: 'profile' 페이지)
            return redirect('home_login')
        else:
            # form.add_error(None, "Invalid username or password")
            return render(request, 'login_logout.html')
    return render(request, 'login_logout.html')


# def login_view(request):
#     if request.method == 'POST':
#         form = LoginForm(request.POST)
#         if form.is_valid():
#             username = form.cleaned_data['username']
#             password = form.cleaned_data['password']

#             # 사용자 인증
#             user = authenticate(request, username=username, password=password)

#             if user is not None:
#                 # 인증 성공 시 로그인 처리
#                 login(request, user)
#                 return render(request, 'home_login.html', {'user': user})  # 성공 시 home_login.html 반환
#             else:
#                 return JsonResponse({'message': 'Invalid username or password'}, status=401)  # 실패 응답
#         else:
#             return JsonResponse({'message': 'Invalid form data'}, status=400)  # 폼 데이터 유효성 검사 실패

#     return JsonResponse({'message': 'Method not allowed'}, status=405)  # POST 외 요청 처리



# @login_required
# def profile_view(request):
#     # 로그인한 사용자의 이름을 가져옴
#     user_name = request.user.first_name # 로그인한 사용자의 'name' 필드
#     #user_point = request.user.profile.point  # 예: Profile 모델에서 포인트 가져오기 (확인 필요)
#     #user_cjr = request.user.profile.cjr  # 예: Profile 모델에서 캡쮸리 수 가져오기 (확인 필요)
#     return render(request, 'myprofile_login.html', {'user_name': user_name}) #'user_point': user_point, 'user_cjr': user_cjr 이 부분 추가.



#다른 방법
# def profile_view(request):
#     if request.user.is_authenticated:
#         # 로그인된 경우, 사용자 이름을 전달하여 myprofile_login.html을 렌더링
#         user_name = request.user.first_name
#         return render(request, 'myprofile_login.html', {'user_name': user_name})
#     else:
#         # 로그인되지 않은 경우, login_logout.html을 렌더링
#         return render(request, 'login_logout.html')





def home_login_view(request):
    return render(request, 'home_login.html')

# def login_logout_view(request):
#     return render(request, 'login_logout.html')

# def login_login_view(request):
#     return render(request, 'login_login.html')

def map_logout_view(request):
    return render(request, 'map_logout.html')

def map_login_view(request):
    return render(request, 'map_login.html')

def profile_logout_view(request):
    return render(request, 'profile_logout.html')

def profile_login_view(request):
    # if request.user.is_authenticated:
    #     # 로그인된 경우, 사용자 이름을 전달하여 myprofile_login.html을 렌더링
    #     user_name = request.user.name
    #     return render(request, 'myprofile_login.html', {'user_name': user_name})
    # else:
    #     # 로그인되지 않은 경우, login_logout.html을 렌더링
    #     return render(request, 'login_logout.html')
    return render(request, 'profile_login.html')


def store_logout_view(request):
    return render(request, 'store_logout.html')

def store_login_view(request):
    return render(request, 'store_login.html')

def whoweare_logout_view(request):
    return render(request, 'whoweare_logout.html')

def whoweare_login_view(request):
    return render(request, 'whoweare_login.html')
# views.py
import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt  # CSRF 비활성화가 필요할 경우

# views.py
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
# from .forms import SignUpForm
# from .forms import LoginForm
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from .models import UserInfo, UserPurchased, Item # 구매 정보를 저장할 모델

#1117에 추가함.
# from django.http import HttpResponseNotFound
from django.http import HttpResponse

def home_logout_view(request):
    return render(request, 'home_logout.html')  # 템플릿 파일 위치는 templates/home.html

def home_login_view(request):
    return render(request, 'home_login.html')

def join_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        name = request.POST.get('first_name')
        
        if not username or not password or not name:
            return HttpResponse("All fields are required.", status=400)
        try:
            User.objects.create_user(username=username, password=password, first_name=name)
            return redirect('home_login')
        except Exception as e:
            return HttpResponse(f"Error: {str(e)}", status=400)
    return render(request, "join_logout.html")

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        # 사용자 인증
        user = authenticate(request, username=username, password=password)  #로그인 검증

        if user is not None:
            login(request, user)
            return redirect('home_login')
        else:
            return render(request, 'login_logout.html')
    return render(request, 'login_logout.html')

def map_logout_view(request):
    return render(request, 'map_logout.html')

def map_login_view(request):
    return render(request, 'map_login.html')

def profile_logout_view(request):
    return render(request, 'profile_logout.html')

def profile_login_view(request):
    user = UserInfo.objects.filter(user=request.user)[0]
    if not user:
        user = UserInfo(user=request.user, points=0)
        user.save()
    return render(request, 'profile_login.html', {'info':user, 'purchases':UserPurchased.objects.filter(user=request.user)})


def store_logout_view(request):
    return render(request, 'store_logout.html')

def store_login_view(request):
    return render(request, 'store_login.html')

@login_required
def find_item(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        uinfo = UserInfo.objects.filter(user=request.user)[0]
        uinfo.points += int(data.get('earn_points'))
        uinfo.save()

    return JsonResponse({'success': True, 'message': f'요청 성공'})
@login_required
def purchase_item(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        item_name = data.get('item_name')
        item_points = int(data.get('item_points'))

        # Validate user points (assumes user has a points attribute)
        user = request.user
        uinfo = UserInfo.objects.filter(user=user)[0]
        if uinfo.points < item_points:
            return JsonResponse({'success': False, 'message': '포인트가 부족합니다.'})

        # Fetch the item
        try:
            item = Item.objects.get(item_name=item_name)
        except Item.DoesNotExist:
            return JsonResponse({'success': False, 'message': '아이템을 찾을 수 없습니다.'})

        # Check if already purchased
        if UserPurchased.objects.filter(user=user, item=item).exists():
            return JsonResponse({'success': False, 'message': '이미 구매한 아이템입니다.'})
        
        
        # Deduct points and save the purchase
        uinfo.points -= item_points
        uinfo.save()

        UserPurchased.objects.create(user=user, item=item)

        return JsonResponse({'success': True, 'message': f'{item_name} 구매 완료!'})
    else:
        return JsonResponse({'success': False, 'message': 'Invalid request method.'})

def whoweare_logout_view(request):
    return render(request, 'whoweare_logout.html')

def whoweare_login_view(request):
    return render(request, 'whoweare_login.html')

def capturelist_login_view(request):
    return render(request, 'capturelist_login.html')

def capturelist_logout_view(request):
    return render(request, 'capturelist_logout.html')
# views.py
import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt  # CSRF 비활성화가 필요할 경우

# views.py
from django.shortcuts import render, redirect
from django.contrib.auth import login
from .forms import SignUpForm
from django.contrib.auth.models import User
from django.urls import reverse

#1117에 추가함.
# from django.http import HttpResponseNotFound
from django.http import HttpResponse

def home_logout_view(request):
    return render(request, 'home_logout.html')  # 템플릿 파일 위치는 templates/home.html

def join_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        name = request.POST.get('name')
         # 데이터 유효성 검사
        if not username or not password or not name:
            return HttpResponse("All fields are required.", status=400)
        try:
            user = User.objects.create_user(username=username, password=password, first_name=name)
            return redirect('home_login')
        except Exception as e:
            return HttpResponse(f"Error: {str(e)}", status=400)
    return render(request, "join_logout.html")

def home_login_view(request):
    return render(request, 'home_login.html')

def login_logout_view(request):
    return render(request, 'login_logout.html')

def login_login_view(request):
    return render(request, 'login_login.html')

def map_logout_view(request):
    return render(request, 'map_logout.html')

def map_login_view(request):
    return render(request, 'map_login.html')

def profile_logout_view(request):
    return render(request, 'profile_logout.html')

def profile_login_view(request):
    return render(request, 'profile_login.html')

def store_logout_view(request):
    return render(request, 'store_logout.html')

def store_login_view(request):
    return render(request, 'store_login.html')

def whoweare_logout_view(request):
    return render(request, 'whoweare_logout.html')

def whoweare_login_view(request):
    return render(request, 'whoweare_login.html')
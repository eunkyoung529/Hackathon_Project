
from django.contrib.auth.forms import UserCreationForm


# 11.18 수정
from django import forms
from django.contrib.auth.models import User

class SignUpForm(UserCreationForm):
    id = forms.CharField(max_length=50, required=True, label='id')
    password = forms.CharField(max_length=50, required=True, label='passowrd')
    name = forms.CharField(max_length=50, required=True, label='Full Name')
    class Meta:
        model = User
        fields = ['id', 'password', 'name']

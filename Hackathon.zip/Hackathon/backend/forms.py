
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm


# 11.18 수정
from django import forms
from django.contrib.auth.models import User

class SignUpForm(UserCreationForm):
    username = forms.CharField(max_length=50, required=True, label='username')
    password = forms.CharField(max_length=50, required=True, label='passowrd')
    first_name = forms.CharField(max_length=50, required=True, label='first_name')
    class Meta:
        model = User
        fields = ['username', 'password', 'first_name']


class LoginForm(AuthenticationForm):
    username = forms.CharField(label='username', max_length=50)
    password = forms.CharField(label='password', max_length=50)
# views.py
import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt  # CSRF 비활성화가 필요할 경우


# views.py
from django.shortcuts import render, redirect
from django.contrib.auth import login
from .forms import SignUpForm

def signup_view(request):
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect("home.html")  # 홈 또는 다른 페이지로 리디렉션
    else:
        form = SignUpForm()
    return render(request, "join.html", {"form": form})

@csrf_exempt
def my_api_view(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)  # JSON 데이터 파싱
            received_data = data.get('data')
            response_data = {'message': f'받은 데이터: {received_data}'}
            return JsonResponse(response_data)
        except json.JSONDecodeError:
            return JsonResponse({'error': '잘못된 JSON 데이터입니다.'}, status=400)
    else:
        return JsonResponse({'error': 'POST 요청만 허용됩니다.'}, status=400)

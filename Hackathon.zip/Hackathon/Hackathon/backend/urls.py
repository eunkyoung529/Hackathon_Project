from django.contrib import admin
from django.urls import path
from . import views  # views.py에서 함수 불러오기

urlpatterns = [
    path('', views.home_logout_view, name='home_logout'),  # 빈 경로 처리 추가
    path('home_login/', views.home_login_view, name='home_login'),
    path('join_logout/', views.join_view, name='join_logout'),
    path('login_logout/', views.login_logout_view, name='login_logout'),
    path('map_logout/', views.map_logout_view, name='map_logout'),
    path('profile_logout/', views.profile_logout_view, name='profile_logout'),
    path('store_logout/', views.store_logout_view, name='store_logout'),
    path('whoweare_logout/', views.whoweare_logout_view, name='whoweare_logout'),
    path('join_login/', views.join_view, name='join_login'),
    path('login_login/', views.login_login_view, name='login_login'),
    path('map_login/', views.map_login_view, name='map_login'),
    path('profile_login/', views.profile_login_view, name='profile_login'),
    path('store_login/', views.store_login_view, name='store_login'),
    path('whoweare_login/', views.whoweare_login_view, name='whoweare_login'),

]
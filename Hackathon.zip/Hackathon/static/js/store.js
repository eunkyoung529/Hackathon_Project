function purchaseItem(element, user) {
    const itemName = element.getAttribute('data-name'); // 아이템 이름
    const itemPoints = element.getAttribute('data-points');

    // 이미 구매된 상태인지 확인
    if (element.classList.contains('purchased')) {
        alert('이미 구매한 아이템입니다!');
        return; // 함수 종료
    }

    // 경고창 띄우기
    const confirmation = confirm(`'${itemName}'을(를) ${itemPoints}포인트에 구매하시겠습니까?`);

    if (confirmation) {
        fetch('/purchase-item/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCSRFToken(),
            },
            body: JSON.stringify({
                item_name: itemName,
                item_points: itemPoints,
            }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(data.message);
                element.classList.add('purchased');
                element.style.opacity = '0.5';
                element.style.pointerEvents = 'none';
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('문제가 발생했습니다. 다시 시도해주세요.');
        });
    } else {
        alert('구매가 취소되었습니다.');
    }
}

function getCSRFToken() {
    const cookies = document.cookie.split(';');
    for (const cookie of cookies) {
        const [name, value] = cookie.trim().split('=');
        if (name === 'csrftoken') {
            return value;
        }
    }
    return '';
}

import os
import django

# Step 1: Set DJANGO_SETTINGS_MODULE to point to your Django settings file
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'Hackathon.settings')  # Replace 'your_project' with your project name

# Step 2: Initialize Django
django.setup()